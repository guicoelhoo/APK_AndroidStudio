package br.gov.sp.cps.imagens;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView imgPadrao;
    private ImageView imgTesoura;
    private ImageView imgPedra;
    private ImageView imgPapel;
    private TextView txtResultado;
    private TextView txtPlacar;
    private TextView txtModo;

    private int pontoPC = 0;
    private int pontoUser = 0;

    private Button btnLimpar;
    private Button btnMelhorde3;
    private Boolean melhorDe3 = false;
    private Boolean normal = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Instanciando os compontes da interace:
        imgPadrao = findViewById(R.id.imgPadrao);
        imgPedra = findViewById(R.id.imgPedra);
        imgPapel = findViewById(R.id.imgPapel);
        imgTesoura = findViewById(R.id.imgTesoura);
        txtResultado = findViewById(R.id.txtResultado);
        txtPlacar = findViewById(R.id.txtPlacar);
        txtModo = findViewById(R.id.txtModo);
        btnLimpar = findViewById(R.id.btnLimpar);
        btnMelhorde3 = findViewById(R.id.btnMelhorde3);

        //Clique - Tesoura;
        imgTesoura.setOnClickListener(view -> {
            opcSelecionada("tesoura");
        });

        //Clique - Pedra;
        imgPedra.setOnClickListener(view -> {
            opcSelecionada("pedra");
        });

        //Clique - Papel;
        imgPapel.setOnClickListener(view -> {
            opcSelecionada("papel");
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void opcSelecionada(String opcaoSelecionada){

        // Verifica modo
        if (melhorDe3 && !normal){
            return;
        }

        //Escolha aleatoria do PC:
        int numero = new Random().nextInt(3);
        String[] opcoes = {"pedra", "papel", "tesoura"};
        String opPC = opcoes[numero];

        //Apresentando da imagem corespondete do PC:
        switch (opPC){
            case "pedra":
                imgPadrao.setImageResource(R.drawable.pedra);
                break;

            case "papel":
                imgPadrao.setImageResource(R.drawable.papel);
                break;

            case "tesoura":
                imgPadrao.setImageResource(R.drawable.tesoura);
                break;
        }

        //Verifica vencedor:
        if (
            //PC ganha
                (opPC.equals("tesoura") && opcaoSelecionada.equals("papel")) ||
                (opPC.equals("papel") && opcaoSelecionada.equals("pedra")) ||
                (opPC.equals("pedra") && opcaoSelecionada.equals("tesoura"))

        ){
            txtResultado.setText("Perdeu!!!");
            pontoPC++;
            txtPlacar.setText(pontoUser + "X" + pontoPC);


        }else if(
            // User ganha:
                (opcaoSelecionada.equals("tesoura") && opPC.equals("papel")) ||
                (opcaoSelecionada.equals("papel") && opPC.equals("pedra")) ||
                (opcaoSelecionada.equals("pedra") && opPC.equals("tesoura"))
        ) {
            txtResultado.setText("Ganhouuuuu!!");
            pontoUser++;
            txtPlacar.setText(pontoUser + "X" + pontoPC);
        }else{
            txtResultado.setText("Empatou!");
        }

        if (melhorDe3){
            if (pontoUser == 2){
                txtResultado.setText("Você ganhou!");
                normal = false;
            } else if (pontoPC == 2) {
                txtResultado.setText("Máquina ganhou!");
                normal = false;
            }


        }

        // Btn limpar:
        btnLimpar.setOnClickListener(view -> {

            // limpa a imagem
            imgPadrao.setImageResource(R.drawable.padrao);

            // limpa placar e resultado
            txtPlacar.setText("0X0");
            txtResultado.setText("");
            txtModo.setText("Modo normal");

            // zera os pontos
            pontoPC = 0;
            pontoUser = 0;

            // muda modos
            melhorDe3 = false;
            normal = true;

        });

        // Btn melhor de 3:
        btnMelhorde3.setOnClickListener(view -> {
            // Muda mensagem e placar
            txtModo.setText("Modo melhor de 3");
            txtPlacar.setText("0x0");
            txtResultado.setText("");
            melhorDe3 = true;
            normal = true;
            pontoPC = 0;
            pontoUser = 0;
        });

    }
}