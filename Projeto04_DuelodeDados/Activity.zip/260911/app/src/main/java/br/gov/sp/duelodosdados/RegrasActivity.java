package br.gov.sp.duelodosdados;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class RegrasActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regras);

        Button btnVoltarRegras = findViewById(R.id.btnVoltarRegras);
        btnVoltarRegras.setOnClickListener(v -> finish());
    }
}