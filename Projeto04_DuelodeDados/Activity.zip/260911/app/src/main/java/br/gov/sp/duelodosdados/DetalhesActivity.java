package br.gov.sp.duelodosdados;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetalhesActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes);

        Intent intent = getIntent();

        TextView txtDetNome = findViewById(R.id.txtDetNome);
        txtDetNome.setText("Jogador: " + intent.getStringExtra("NOME"));

        TextView txtDetDado1Jog = findViewById(R.id.txtDetDado1Jog);
        txtDetDado1Jog.setText("Dado 1 (Jogador): " + intent.getIntExtra("DADO1_JOG", 0));

        TextView txtDetDado2Jog = findViewById(R.id.txtDetDado2Jog);
        txtDetDado2Jog.setText("Dado 2 (Jogador): " + intent.getIntExtra("DADO2_JOG", 0));

        TextView txtDetSomaJog = findViewById(R.id.txtDetSomaJog);
        txtDetSomaJog.setText("Total Jogador: " + intent.getIntExtra("SOMA_JOG", 0));

        TextView txtDetClassificacao = findViewById(R.id.txtDetClassificacao);
        txtDetClassificacao.setText("Classificação da Jogada: " + intent.getStringExtra("CLASSIFICACAO"));

        TextView txtDetDado1Comp = findViewById(R.id.txtDetDado1Comp);
        txtDetDado1Comp.setText("Dado 1 (Comp): " + intent.getIntExtra("DADO1_COMP", 0));

        TextView txtDetDado2Comp = findViewById(R.id.txtDetDado2Comp);
        txtDetDado2Comp.setText("Dado 2 (Comp): " + intent.getIntExtra("DADO2_COMP", 0));

        TextView txtDetSomaComp = findViewById(R.id.txtDetSomaComp);
        txtDetSomaComp.setText("Total Computador: " + intent.getIntExtra("SOMA_COMP", 0));

        TextView txtDetResultado = findViewById(R.id.txtDetResultado);
        txtDetResultado.setText("Resultado: " + intent.getStringExtra("RESULTADO"));

        TextView txtDetDupla = findViewById(R.id.txtDetDupla);
        txtDetDupla.setText("Dupla: " + intent.getStringExtra("DUPLA"));

        Button btnVoltar = findViewById(R.id.btnVoltarDet);
        btnVoltar.setOnClickListener(v -> finish());
    }
}