package br.gov.sp.duelodosdados;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText edtNomeJogador;
    private ImageView imgDadoJogador1, imgDadoJogador2, imgDadoComputador1, imgDadoComputador2;
    private TextView txtSomaJogador, txtSomaComputador, txtResultado, txtPlacarJogador, txtPlacarComputador;
    private Switch switchMelhorDe3;
    private Button btnJogar, btnDetalhes, btnRegras, btnNovaPartida;

    private int placarJogador = 0, placarComputador = 0;
    private boolean jogoIniciado = false, melhorDe3Encerrado = false;
    private int ultimoDadoJog1, ultimoDadoJog2, ultimoDadoComp1, ultimoDadoComp2;
    private int ultimaSomaJog, ultimaSomaComp;
    private String ultimoResultado, infoDupla, classificacaoJogada;

    // Imagens que você já colocou na pasta res/drawable
    private final int[] imagensDados = {
            R.drawable.dice1, R.drawable.dice2, R.drawable.dice3,
            R.drawable.dice4, R.drawable.dice5, R.drawable.dice6
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNomeJogador = findViewById(R.id.edtNomeJogador);
        imgDadoJogador1 = findViewById(R.id.imgDadoJogador1);
        imgDadoJogador2 = findViewById(R.id.imgDadoJogador2);
        imgDadoComputador1 = findViewById(R.id.imgDadoComputador1);
        imgDadoComputador2 = findViewById(R.id.imgDadoComputador2);
        txtSomaJogador = findViewById(R.id.txtSomaJogador);
        txtSomaComputador = findViewById(R.id.txtSomaComputador);
        txtResultado = findViewById(R.id.txtResultado);
        txtPlacarJogador = findViewById(R.id.txtPlacarJogador);
        txtPlacarComputador = findViewById(R.id.txtPlacarComputador);
        switchMelhorDe3 = findViewById(R.id.switchMelhorDe3);

        btnJogar = findViewById(R.id.btnJogar);
        btnDetalhes = findViewById(R.id.btnDetalhes);
        btnRegras = findViewById(R.id.btnRegras);
        btnNovaPartida = findViewById(R.id.btnNovaPartida);

        btnJogar.setOnClickListener(v -> realizarJogada());
        btnNovaPartida.setOnClickListener(v -> iniciarNovaPartida());

        btnRegras.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, RegrasActivity.class)));
        btnDetalhes.setOnClickListener(v -> {
            if (!jogoIniciado) Toast.makeText(this, "Realize uma jogada primeiro!", Toast.LENGTH_SHORT).show();
            else abrirDetalhes();
        });
    }

    private void realizarJogada() {
        String nome = edtNomeJogador.getText().toString().trim();
        if (nome.isEmpty()) {
            Toast.makeText(this, "Informe seu nome antes de jogar.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (melhorDe3Encerrado) {
            Toast.makeText(this, "Partida encerrada. Inicie uma nova.", Toast.LENGTH_SHORT).show();
            return;
        }

        Random random = new Random();
        int indexJog1 = random.nextInt(6);
        int indexJog2 = random.nextInt(6);
        int indexComp1 = random.nextInt(6);
        int indexComp2 = random.nextInt(6);

        imgDadoJogador1.setImageResource(imagensDados[indexJog1]);
        imgDadoJogador2.setImageResource(imagensDados[indexJog2]);
        imgDadoComputador1.setImageResource(imagensDados[indexComp1]);
        imgDadoComputador2.setImageResource(imagensDados[indexComp2]);

        ultimoDadoJog1 = indexJog1 + 1;
        ultimoDadoJog2 = indexJog2 + 1;
        ultimoDadoComp1 = indexComp1 + 1;
        ultimoDadoComp2 = indexComp2 + 1;

        ultimaSomaJog = ultimoDadoJog1 + ultimoDadoJog2;
        ultimaSomaComp = ultimoDadoComp1 + ultimoDadoComp2;

        txtSomaJogador.setText("Soma: " + ultimaSomaJog);
        txtSomaComputador.setText("Soma: " + ultimaSomaComp);

        if (ultimaSomaJog <= 5) classificacaoJogada = "Baixa";
        else if (ultimaSomaJog <= 8) classificacaoJogada = "Média";
        else classificacaoJogada = "Alta";

        infoDupla = "Nenhuma";
        if (ultimoDadoJog1 == ultimoDadoJog2) {
            infoDupla = "Jogador obteve DUPLA!";
            Toast.makeText(this, infoDupla, Toast.LENGTH_SHORT).show();
        }
        if (ultimoDadoComp1 == ultimoDadoComp2) Toast.makeText(this, "Computador obteve DUPLA!", Toast.LENGTH_SHORT).show();

        if (ultimaSomaJog > ultimaSomaComp) {
            ultimoResultado = nome + " venceu a rodada!";
            placarJogador++;
        } else if (ultimaSomaComp > ultimaSomaJog) {
            ultimoResultado = "Computador venceu a rodada!";
            placarComputador++;
        } else {
            ultimoResultado = "Empate!";
        }

        txtResultado.setText(ultimoResultado);
        txtPlacarJogador.setText("Jogador: " + placarJogador);
        txtPlacarComputador.setText("Computador: " + placarComputador);
        jogoIniciado = true;

        if (switchMelhorDe3.isChecked()) {
            if (placarJogador == 2) {
                txtResultado.setText("FIM DE PARTIDA: " + nome + " é o Campeão!");
                melhorDe3Encerrado = true;
                btnJogar.setEnabled(false);
            } else if (placarComputador == 2) {
                txtResultado.setText("FIM DE PARTIDA: Computador é o Campeão!");
                melhorDe3Encerrado = true;
                btnJogar.setEnabled(false);
            }
        }
    }

    private void iniciarNovaPartida() {
        placarJogador = 0;
        placarComputador = 0;
        jogoIniciado = false;
        melhorDe3Encerrado = false;
        txtPlacarJogador.setText("Jogador: 0");
        txtPlacarComputador.setText("Computador: 0");
        txtSomaJogador.setText("Soma: -");
        txtSomaComputador.setText("Soma: -");
        txtResultado.setText("Faça sua jogada!");
        imgDadoJogador1.setImageDrawable(null);
        imgDadoJogador2.setImageDrawable(null);
        imgDadoComputador1.setImageDrawable(null);
        imgDadoComputador2.setImageDrawable(null);
        btnJogar.setEnabled(true);
    }

    private void abrirDetalhes() {
        Intent intent = new Intent(MainActivity.this, DetalhesActivity.class);
        intent.putExtra("NOME", edtNomeJogador.getText().toString());
        intent.putExtra("DADO1_JOG", ultimoDadoJog1);
        intent.putExtra("DADO2_JOG", ultimoDadoJog2);
        intent.putExtra("SOMA_JOG", ultimaSomaJog);
        intent.putExtra("CLASSIFICACAO", classificacaoJogada);
        intent.putExtra("DADO1_COMP", ultimoDadoComp1);
        intent.putExtra("DADO2_COMP", ultimoDadoComp2);
        intent.putExtra("SOMA_COMP", ultimaSomaComp);
        intent.putExtra("RESULTADO", ultimoResultado);
        intent.putExtra("DUPLA", infoDupla);
        startActivity(intent);
    }
}