package br.gov.sp.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private int carroSelecionado = 1; // Variável para rastrear qual carro está na tela

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Referenciando os itens da tela
        ImageView fig = findViewById(R.id.fig);
        ImageView botao1 = findViewById(R.id.botao1);
        ImageView botao2 = findViewById(R.id.botao2);
        ImageView botao3 = findViewById(R.id.botao3);
        TextView btnDetalhes = findViewById(R.id.btnDetalhes);
        ImageView delete = findViewById(R.id.delete);

        // Ações de clique para trocar a imagem (Substitua carro1, carro2, carro3 pelo nome real das suas imagens na pasta drawable)
        botao1.setOnClickListener(v -> {
            fig.setImageResource(R.drawable.byd);
            carroSelecionado = 1;
        });

        botao2.setOnClickListener(v -> {
            fig.setImageResource(R.drawable.fusca);
            carroSelecionado = 2;
        });

        botao3.setOnClickListener(v -> {
            fig.setImageResource(R.drawable.kwid);
            carroSelecionado = 3;
        });

        // Ação para o botão Delete (volta para a logo inicial)
        delete.setOnClickListener(v -> {
            fig.setImageResource(R.drawable.fig);
            carroSelecionado = 0; // Opcional, 0 pode significar nenhum carro
        });

        // Ação para ir para a tela de detalhes
        btnDetalhes.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
            // Passa a informação de qual carro estava selecionado para a próxima tela
            intent.putExtra("CARRO_SELECIONADO", carroSelecionado);
            startActivity(intent);
        });
    }
}