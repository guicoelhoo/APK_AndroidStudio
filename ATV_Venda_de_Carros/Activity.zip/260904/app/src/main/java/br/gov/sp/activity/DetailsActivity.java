package br.gov.sp.activity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailsActivity extends AppCompatActivity {

    private int indexCarroAtual;

    // Arrays contendo as referências das imagens e dos textos em ordem
    private final int[] imagensCarros = {R.drawable.byd, R.drawable.fusca, R.drawable.kwid};
    private final String[] descricoesCarros = {
            "Carro 1: Carro eletrico chavoso.",
            "Carro 2: Modelo para passar na frente das escolas.",
            "Carro 3: Pior carro do mundo."
    };

    private ImageView imgDetalheCarro;
    private TextView txtDetalheCarro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        imgDetalheCarro = findViewById(R.id.imgDetalheCarro);
        txtDetalheCarro = findViewById(R.id.txtDetalheCarro);
        Button btnVoltar = findViewById(R.id.btnVoltar);
        Button btnAvancar = findViewById(R.id.btnAvancar);

        // Recebe o carro selecionado da MainActivity (padrão é 1 se houver erro)
        int carroRecebido = getIntent().getIntExtra("CARRO_SELECIONADO", 1);

        // Ajusta para o índice do Array (0 a 2)
        // Se carro for 0 (nenhum selecionado), forçamos para 0 (primeiro carro)
        indexCarroAtual = (carroRecebido == 0) ? 0 : carroRecebido - 1;

        atualizarTela();

        btnAvancar.setOnClickListener(v -> {
            if (indexCarroAtual < imagensCarros.length - 1) {
                indexCarroAtual++;
            } else {
                indexCarroAtual = 0; // Volta para o primeiro se passar do último
            }
            atualizarTela();
        });

        btnVoltar.setOnClickListener(v -> {
            if (indexCarroAtual > 0) {
                indexCarroAtual--;
            } else {
                indexCarroAtual = imagensCarros.length - 1; // Vai para o último se voltar antes do primeiro
            }
            atualizarTela();
        });
    }

    private void atualizarTela() {
        imgDetalheCarro.setImageResource(imagensCarros[indexCarroAtual]);
        txtDetalheCarro.setText(descricoesCarros[indexCarroAtual]);
    }
}