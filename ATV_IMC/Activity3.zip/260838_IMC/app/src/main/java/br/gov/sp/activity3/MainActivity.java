package br.gov.sp.activity3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {


    // Declarar os componentes:
    private EditText txtNome;
    private EditText txtPeso;
    private EditText txtAltura;
    private TextView txtResultado;
    private Button btnCalcular;
    private Button btnLimpar;


    // Limpa os campos ao voltar a tela
    @Override
    protected void onResume() {
        super.onResume();

        txtNome.setText("");
        txtPeso.setText("");
        txtAltura.setText("");
        txtResultado.setText("Resultado");
        // retorna o cursor para nome:
        txtNome.requestFocus();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Define o layout do projeto (activity_main.xml):
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Relacionar os componentes XML:
        txtNome = findViewById(R.id.txtNome);
        txtPeso = findViewById(R.id.txtPeso);
        txtAltura = findViewById(R.id.txtAltura);
        txtResultado = findViewById(R.id.txtResultado);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnLimpar = findViewById(R.id.btnLimpar);

        // Btn calcular:
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // recupera os valores digitados

                String nome = txtNome.getText().toString();
                String peso = txtPeso.getText().toString();
                String altura = txtAltura.getText().toString();

                // verifica se os campos foram preenchidos corretamente

                if (nome.isEmpty() || peso.isEmpty() || altura.isEmpty()){
                    txtResultado.setText("Preencha os campos!");
                    return;
                }

                // converte os valores

                double numPeso = Double.parseDouble(peso);
                double numAltura = Double.parseDouble(altura);
                numAltura = numAltura/100;

                // calcula o imc

                double numImc = numPeso / (numAltura*numAltura);

                // classificação de imc

                String classImc;

                if (numImc < 18.5){classImc = "Abaixo do peso";
                } else if (numImc < 25) {classImc = "Peso normal";
                } else if (numImc < 30) {classImc = "Sobrepeso";
                } else if (numImc < 35) {classImc = "Obesidade grau I";
                } else if (numImc < 40) {classImc = "Obesidade grau II";
                } else { classImc = "Obesidade grau III" ;}

                // formata o resultado com uma casa decimal

                String formataImc = String.format(Locale.US, "%.1f", numImc);

                if (classImc.equals("Abaixo do peso")) {
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    intent.putExtra("nome", nome);
                    intent.putExtra("classImc", classImc);
                    intent.putExtra("imc", formataImc);
                    startActivity(intent);

                } else if (classImc.equals("Peso normal")) {
                    Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                    intent.putExtra("nome", nome);
                    intent.putExtra("classImc", classImc);
                    intent.putExtra("imc", formataImc);
                    startActivity(intent);

                } else if (classImc.equals("Sobrepeso")) {
                    Intent intent = new Intent(MainActivity.this, MainActivity4.class);
                    intent.putExtra("nome", nome);
                    intent.putExtra("classImc", classImc);
                    intent.putExtra("imc", formataImc);
                    startActivity(intent);

                } else if (classImc.equals("Obesidade grau I")) {
                    Intent intent = new Intent(MainActivity.this, MainActivity5.class);
                    intent.putExtra("nome", nome);
                    intent.putExtra("classImc", classImc);
                    intent.putExtra("imc", formataImc);
                    startActivity(intent);

                } else if (classImc.equals("Obesidade grau II")) {
                    Intent intent = new Intent(MainActivity.this, MainActivity6.class);
                    intent.putExtra("nome", nome);
                    intent.putExtra("classImc", classImc);
                    intent.putExtra("imc", formataImc);
                    startActivity(intent);

                } else {
                    Intent intent = new Intent(MainActivity.this, MainActivity7.class);
                    intent.putExtra("nome", nome);
                    intent.putExtra("classImc", classImc);
                    intent.putExtra("imc", formataImc);
                    startActivity(intent);
                }
            }
        });


        // Btn limpar:
        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // limpar os campos
                txtNome.setText("");
                txtPeso.setText("");
                txtAltura.setText("");

                // limpar o resultado (retorna padrão)
                txtResultado.setText("Resultado");

                // retorna o cursor para nome:
                txtNome.requestFocus();
            }
        });

    }
}