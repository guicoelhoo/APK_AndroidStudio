package br.gov.sp.activity3;


import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity5 extends AppCompatActivity {


    // Declarar os componentes:
    private TextView txtNome;
    private TextView txtClassificacao;
    private TextView txtImc;
    private Button btnVoltar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Define o layout do projeto (activity_main.xml):
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main5);

        // Relacionar os componentes XML:
        txtNome = findViewById(R.id.txtNome);
        txtClassificacao = findViewById(R.id.txtClassificacao);
        txtImc = findViewById(R.id.txtImc);
        btnVoltar = findViewById(R.id.btnVoltar);

        // Recebe os dados
        Bundle bundle = getIntent().getExtras();

        // Decompoem os dados:
        String nome = bundle.getString("nome");
        String classificacao = bundle.getString("classImc");
        String imc = bundle.getString("imc");

        // Mostrar o resultado
        String resultadoNome = "Nome: " + nome;
        String resultadoClassImc = classificacao;
        String resultadoImc = "IMC: " + imc;

        txtNome.setText(resultadoNome);
        txtClassificacao.setText(resultadoClassImc);
        txtImc.setText(resultadoImc);

        // Btn voltar
        btnVoltar.setOnClickListener(view -> {
            finish();
        });

    }
}


